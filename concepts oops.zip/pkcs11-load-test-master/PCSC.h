#pragma once
#include "stdafx.h"

#include "Log.h"
#include <string>

using namespace std;

class PCSC
{
public:
    PCSC(void);
    ~PCSC(void);

    // Helper function to retrieve the GlobalPlatform CPLC IC Serial Number given a supplied reader name.
    static string QueryCPLC(string reader);
};

