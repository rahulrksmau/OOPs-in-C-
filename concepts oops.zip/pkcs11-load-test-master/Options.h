#pragma once

#include <windows.h>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

class Options
{

public:
    Options();
    ~Options(void);

    // Parse the command-line arguments into the Options instance
   // bool Parse(int argc, _TCHAR* argv[]); # st
	bool Parse();
public:
    // Argument - The name of this executable (passed through as argv[0])
    string EXEName;

    // Argument - The path to the PKCS11 library
    wstring PKCS11Library;

    // Argument - The PIN to be used for the PKCS11 Login (Normal User)
    wstring PIN;

    // Argument - The ID value of the RSA key pair to be used for the crypto operations
    char KeyId[255];

    // Argument - The length of the supplied Key ID
    int KeyIdLength;

    // Argument - The number of process iterations to perform before shutting down.
    int MaxIterations;

    // Argument - The period of time to wait between each process
    int Interval;
};

