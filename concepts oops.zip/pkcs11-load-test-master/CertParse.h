#pragma once

#include "stdafx.h"

#include "openssl\x509.h"
#include "openssl\x509v3.h"
#include "openssl\bio.h"
#include "openssl\pem.h"

#include <string>
using namespace std;

class CertParser {
	public:
		CertParser();
		~CertParser();
		bool parseInit(string path);
		string getSubject();
		string getIssuer();

	private:
		X509 * cert;
};
