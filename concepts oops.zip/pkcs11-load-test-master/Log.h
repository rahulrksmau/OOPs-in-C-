#pragma once
#include "stdafx.h"

#include <iostream>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

#define LOG_DEFAULT_LEVEL   LOG_INFO

#define	LOG_EMERG	0	/* system is unusable */
#define	LOG_ALERT	1	/* action must be taken immediately */
#define	LOG_CRIT	2	/* critical conditions */
#define	LOG_ERR		3	/* error conditions */
#define	LOG_WARNING	4	/* warning conditions */
#define	LOG_NOTICE	5	/* normal but significant condition */
#define	LOG_INFO	6	/* informational */
#define	LOG_DEBUG	7	/* debug-level messages */

class Log
{

public:
    static void debug(const char * fmt, ...);
    static void warn(const char * fmt, ...);
    static void error(const char * fmt, ...);
    static void info(const char * fmt, ...);
    static void notice(const char * fmt, ...);

    static void setLevel(int level);
    static int getLevel();

private:
    static int m_LogLevel;
};
