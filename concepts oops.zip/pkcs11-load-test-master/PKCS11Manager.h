#pragma once
#include "stdafx.h"

#include <iostream>
#include <string>
#include <vector>

#include "include/cryptoki.h"
#include "PKCS11Slot.h"

using namespace std;

class PKCS11Manager
{
private:
    static PKCS11Manager * m_Instance;
    static HINSTANCE hPKCS11;
    static CK_FUNCTION_LIST * pPKCS11;

private:
    PKCS11Manager(void);

public:
    ~PKCS11Manager(void);

    // Singleton creation / reference method.
    static PKCS11Manager* Create(LPCTSTR libraryPath);
    static void Destroy();

    // List the available slots
    int QuerySlots(bool tokenPresent, vector<PKCS11Slot> * slots);

public:
};
