#pragma once
#include "stdafx.h"

#include <cstdio>
#include <iostream>
#include <string>
#include <fstream>

#include "openssl\bio.h"
#include "openssl\pem.h"
#include "openssl\x509.h"
#include "openssl\err.h"

using namespace std;

struct CSR_data {
	string common_name, general_name, country, email_address, organisation_unit, organisation, state, locality, digest_algo;
	int rsa_strength;
};

class GenerateCSR {
public:

	GenerateCSR(CSR_data csr);
	string csr_to_text();
	~GenerateCSR();
private:
	CSR_data csr;
	EVP_PKEY *pkey;
	X509_REQ *webrequest;
	X509_NAME *reqname;
	EVP_MD const *digest;

	int generateRSA(int strength);
	void assign_feild(string feild, string value);
	int write_to_disk(X509_REQ* csr, string file);
};