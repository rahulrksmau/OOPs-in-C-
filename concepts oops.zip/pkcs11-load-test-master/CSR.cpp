#include "stdafx.h"
#include "CSR.h"


int GenerateCSR::generateRSA(int strength=4096)
{
	RSA *myrsa = NULL;
	if (!(pkey = EVP_PKEY_new()))
		return 0;   // new key generation error
	myrsa = RSA_new();
	if ((strength != 2048 || strength != 4096) && !(myrsa = RSA_generate_key(strength, RSA_F4, NULL, NULL)))
		return 0;         // Error generating the RSA key.
	if (!EVP_PKEY_assign_RSA(pkey, myrsa))
		return 0;  // Error assigning RSA key to EVP_PKEY structure.

	return 1;
}

void GenerateCSR::assign_feild(string feild, string value="") {
	X509_NAME_add_entry_by_txt(reqname, feild.c_str(), MBSTRING_UTF8,
		(unsigned char*)value.c_str(), -1, -1, 0);
	
}

GenerateCSR::GenerateCSR(CSR_data certificate_signing_request) {
	csr = certificate_signing_request;
	generateRSA(csr.rsa_strength);
	if ((webrequest = X509_REQ_new()) == NULL)
		return ;    // Error creating new X509_REQ structure.
	if (X509_REQ_set_pubkey(webrequest, pkey) == 0)
		return ; // Error setting public key for X509_REQ structure.
	if ((reqname = X509_REQ_get_subject_name(webrequest)) == NULL)
		return ;   // Error setting public key for X509_REQ structure.
	
	assign_feild("C", csr.country);
	assign_feild("ST", csr.state);
	assign_feild("L", csr.locality);
	assign_feild("OU", csr.organisation_unit);
	assign_feild("O", csr.organisation);
	assign_feild("emailAddress", csr.email_address);
	assign_feild("CN", csr.common_name);
	assign_feild("GN", csr.general_name);

	digest = EVP_sha256();
		// Sign certificate request
		if (!X509_REQ_sign(webrequest, pkey, digest))
			return;    // Error signing X509_REQ structure with SHA256.
	
}

string GenerateCSR::csr_to_text() {

	string result,file_name = "temp.pem";
	write_to_disk(webrequest, file_name);
	ifstream csr_pem(file_name);
	if (csr_pem.is_open()) {
		string line;
		while (getline(csr_pem, line)) {
			if(line[0] != '-')
				result += line;
		}
		csr_pem.close();
	}
	string Begin = "-----BEGIN CERTIFICATE REQUEST-----";
	string End = "-----END CERTIFICATE REQUEST-----";
	size_t pos = result.find(Begin);
	if (pos != string::npos) result.erase(pos, Begin.size());
	size_t rpos = result.rfind(End);
	if (pos != string::npos) result.erase(rpos, End.size());
	return result;
}

int GenerateCSR::write_to_disk(X509_REQ * csr, string file_name)
{
	FILE *fp = NULL;
	int ret;
	fopen_s(&fp, file_name.c_str(), "w");
	if (!fp)
		return 0; // unable to open file
 	else
		ret = PEM_write_X509_REQ(fp, webrequest);
	fclose(fp);
	return ret;
}


GenerateCSR::~GenerateCSR()
{
	EVP_PKEY_free(pkey);
	X509_REQ_free(webrequest);
	X509_NAME_free(reqname);
}
