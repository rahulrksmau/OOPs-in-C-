#pragma once
#include "stdafx.h"
#include "CertParse.h"
#include "Log.h"

CertParser::CertParser()
{
	cert = NULL;
}

CertParser::~CertParser() {
	if (NULL != cert) {
		delete cert;
		cert = NULL;
	}
}

bool CertParser::parseInit(string path)
{
	/*
	BIO  *certbio = NULL;
	int ret;
	certbio = BIO_new(BIO_s_file());
	ret = BIO_read_filename(certbio, path.c_str());
	*/
	BIO *outbio = BIO_new(BIO_s_mem());
	int ret = BIO_write(outbio, (const void*)path.c_str(), path.size());

	if (!(cert = PEM_read_bio_X509(outbio, NULL, 0, NULL))) {
		Log::error( "Error loading cert into memory\n");
		return false;
	}
	return true;
}

string CertParser::getSubject()
{
	char *subj = X509_NAME_oneline(X509_get_subject_name(cert), NULL, 0);
	return string(subj);
}

string CertParser::getIssuer()
{
	char *issuer = X509_NAME_oneline(X509_get_issuer_name(cert), NULL, 0);
	return string(issuer);
}


